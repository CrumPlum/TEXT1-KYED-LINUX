#!/bin/sh
set -eu

script_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
package_dir="$script_dir/kwin-toggle-keep-above"

command -v kpackagetool6 >/dev/null 2>&1 || {
    echo "kpackagetool6 was not found. Install the KDE KWin scripting tools first." >&2
    exit 1
}
command -v kwriteconfig6 >/dev/null 2>&1 || {
    echo "kwriteconfig6 was not found." >&2
    exit 1
}

kpackagetool6 --type=KWin/Script -i "$package_dir"
kwriteconfig6 --file kwinrc --group Plugins --key codex-toggle-keep-aboveEnabled true

if command -v qdbus6 >/dev/null 2>&1; then
    qdbus6 org.kde.KWin /KWin reconfigure
elif command -v qdbus >/dev/null 2>&1; then
    qdbus org.kde.KWin /KWin reconfigure
else
    echo "Script installed and enabled. Log out and back in to load it (qdbus client unavailable)."
fi
