#!/bin/sh
# Copy the current selection and search it from the user's Wayland session.
set -eu

user=sandr
uid=$(/usr/bin/id -u "$user")
runtime="/run/user/$uid"
wayland_display=wayland-0
for socket in "$runtime"/wayland-*; do
    if [ -S "$socket" ]; then
        wayland_display=${socket##*/}
        break
    fi
done
bus="unix:path=$runtime/bus"

# Let the Win+C chord release before injecting Ctrl+C.
sleep 0.3
/usr/bin/keyd do C-c
sleep 0.3
selection="$(runuser -u "$user" -- /usr/bin/env \
    XDG_RUNTIME_DIR="$runtime" \
    WAYLAND_DISPLAY="$wayland_display" \
    DBUS_SESSION_BUS_ADDRESS="$bus" \
    XDG_SESSION_TYPE=wayland \
    /usr/bin/wl-paste --no-newline 2>/dev/null)" || exit 0
[ -n "$selection" ] || exit 0

encoded="$(printf '%s' "$selection" | /usr/bin/python3 -c 'import sys, urllib.parse; print(urllib.parse.quote(sys.stdin.read(), safe=""))')"
url="https://www.google.com/search?q=$encoded"
runuser -u "$user" -- /usr/bin/env \
    XDG_RUNTIME_DIR="$runtime" \
    WAYLAND_DISPLAY="$wayland_display" \
    DBUS_SESSION_BUS_ADDRESS="$bus" \
    XDG_SESSION_TYPE=wayland \
    /usr/bin/flatpak run com.google.Chrome "$url" >/dev/null 2>&1 &

# Bring the existing browser window to the foreground through KWin/kdotool.
sleep 1.0
/usr/local/bin/keyd-raise-chrome
