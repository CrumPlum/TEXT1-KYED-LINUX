#!/bin/sh
# Copy selected text and open its Ukrainian translation in the existing Chrome.
set -eu

user=sandr
uid=$(/usr/bin/id -u "$user")
runtime="/run/user/$uid"
wayland_display=wayland-0
for socket in "$runtime"/wayland-*; do
    if [ -S "$socket" ]; then
        wayland_display=${socket##*/}
        break
    fi
done
bus="unix:path=$runtime/bus"

# Let the Win+T chord release before copying the selection.
sleep 0.3
/usr/bin/keyd do C-c
sleep 0.3
selection="$(runuser -u "$user" -- /usr/bin/env \
    XDG_RUNTIME_DIR="$runtime" \
    WAYLAND_DISPLAY="$wayland_display" \
    DBUS_SESSION_BUS_ADDRESS="$bus" \
    XDG_SESSION_TYPE=wayland \
    /usr/bin/wl-paste --no-newline 2>/dev/null)" || exit 0
[ -n "$selection" ] || exit 0

encoded="$(printf '%s' "$selection" | /usr/bin/python3 -c 'import sys, urllib.parse; print(urllib.parse.quote(sys.stdin.read(), safe=""))')"
url="https://translate.google.com/?sl=auto&tl=uk&text=$encoded&op=translate"
runuser -u "$user" -- /usr/bin/env \
    XDG_RUNTIME_DIR="$runtime" \
    WAYLAND_DISPLAY="$wayland_display" \
    DBUS_SESSION_BUS_ADDRESS="$bus" \
    XDG_SESSION_TYPE=wayland \
    /usr/bin/flatpak run com.google.Chrome "$url" >/dev/null 2>&1 &

sleep 1.0
/usr/local/bin/keyd-raise-chrome
