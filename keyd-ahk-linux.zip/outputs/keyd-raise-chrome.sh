#!/bin/sh
# Activate an existing Chrome window through KWin's Wayland scripting API.
set -eu

user=sandr
uid=$(/usr/bin/id -u "$user")
runtime="/run/user/$uid"
bus="unix:path=$runtime/bus"

as_user() {
    runuser -u "$user" -- /usr/bin/env \
        XDG_RUNTIME_DIR="$runtime" \
        DBUS_SESSION_BUS_ADDRESS="$bus" \
        XDG_SESSION_TYPE=wayland \
        /usr/bin/kdotool "$@"
}

windows="$(as_user search --class chrome 2>/dev/null || true)"
[ -n "$windows" ] || exit 0

for window in $windows; do
    as_user windowactivate "$window" && exit 0
done

exit 0
