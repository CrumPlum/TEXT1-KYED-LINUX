function activateObsidian() {
    const windows = workspace.stackingOrder;
    for (let i = windows.length - 1; i >= 0; --i) {
        const win = windows[i];
        if ((win.desktopFileName === "md.obsidian.Obsidian" ||
                String(win.resourceClass).toLowerCase().includes("obsidian")) &&
            win.normalWindow && win.wantsInput) {
            if (win.minimized) {
                win.minimized = false;
            }
            workspace.activeWindow = win;
            workspace.raiseWindow(win);
            return;
        }
    }
}

registerShortcut(
    "codex-activate-obsidian",
    "Activate Obsidian launched by keyd",
    "F13",
    function () {
        activateObsidian();
    }
);
