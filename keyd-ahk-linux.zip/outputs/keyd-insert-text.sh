#!/bin/sh
# Insert fixed text through the Wayland clipboard, independent of keyboard layout.
set -eu

case "${1:-}" in
    email)
        text='sviraka@gmail.com'
        ;;
    date)
        text=$(/usr/bin/date '+%Y.%m.%d %H:%M')
        ;;
    *)
        text="$(/usr/bin/python3 - "$@" <<'PY'
import sys

parts = []
for value in sys.argv[1:]:
    if not value or any(char not in "0123456789abcdefABCDEF" for char in value):
        raise SystemExit(2)
    parts.append(chr(int(value, 16)))
print("".join(parts), end="")
PY
)"
        ;;
esac

user=sandr
uid=$(/usr/bin/id -u "$user")
runtime="/run/user/$uid"
wayland_display=wayland-0
for socket in "$runtime"/wayland-*; do
    if [ -S "$socket" ]; then
        wayland_display=${socket##*/}
        break
    fi
done
bus="unix:path=$runtime/bus"

as_user() {
    runuser -u "$user" -- /usr/bin/env \
        HOME=/home/sandr \
        XDG_RUNTIME_DIR="$runtime" \
        WAYLAND_DISPLAY="$wayland_display" \
        DBUS_SESSION_BUS_ADDRESS="$bus" \
        XDG_SESSION_TYPE=wayland \
        "$@"
}

# Save existing plain-text clipboard contents where possible.
types="$(as_user /usr/bin/wl-paste --list-types 2>/dev/null || true)"
previous_type=
case "$types" in
    *'text/plain;charset=utf-8'*) previous_type='text/plain;charset=utf-8' ;;
    *text/plain*) previous_type=text/plain ;;
esac
previous_clipboard=
if [ -n "$previous_type" ]; then
    previous_clipboard="$(as_user /usr/bin/wl-paste --type "$previous_type" --no-newline 2>/dev/null || true)"
fi

# Release the shortcut modifiers before pasting the literal text.
sleep 0.2
printf '%s' "$text" | as_user /usr/bin/wl-copy --type text/plain
/usr/bin/keyd do C-v
sleep 0.15

# Restore previous plain text, if the clipboard had a text representation.
if [ -n "$previous_type" ]; then
    printf '%s' "$previous_clipboard" | as_user /usr/bin/wl-copy --type "$previous_type"
fi
