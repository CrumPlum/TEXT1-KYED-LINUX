#!/bin/sh
# Launch the user's Flatpak Obsidian from the root-owned keyd daemon.
set -eu

user=sandr
uid=$(/usr/bin/id -u "$user")
runtime="/run/user/$uid"
wayland_display=wayland-0
for socket in "$runtime"/wayland-*; do
    if [ -S "$socket" ]; then
        wayland_display=${socket##*/}
        break
    fi
done
bus="unix:path=$runtime/bus"

runuser -u "$user" -- /usr/bin/env \
    XDG_RUNTIME_DIR="$runtime" \
    WAYLAND_DISPLAY="$wayland_display" \
    DBUS_SESSION_BUS_ADDRESS="$bus" \
    XDG_SESSION_TYPE=wayland \
    /usr/bin/flatpak run md.obsidian.Obsidian >/dev/null 2>&1 &

# Ask the KWin companion script to activate Obsidian after its window appears.
sleep 1.5
/usr/bin/keyd do f13
