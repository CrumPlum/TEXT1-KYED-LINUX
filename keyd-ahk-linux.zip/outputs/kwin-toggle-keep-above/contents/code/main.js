registerShortcut(
    "codex-toggle-keep-above",
    "Toggle Keep Above for Active Window",
    "F14",
    function () {
        const win = workspace.activeWindow;
        if (win && !win.specialWindow) {
            win.keepAbove = !win.keepAbove;
        }
    }
);
