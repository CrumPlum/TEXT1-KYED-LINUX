# Документація пакета

Актуальні інструкції розміщені в корені пакета:

- [`README-NOBARA.md`](../README-NOBARA.md) — встановлення на Nobara KDE Wayland цього комп'ютера.
- [`README-LINUX.md`](../README-LINUX.md) — адаптація та встановлення на іншому Linux.
- [`GUIDE.md`](../GUIDE.md) — повний довідник комбінацій клавіш.
