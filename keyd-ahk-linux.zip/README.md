# keyd layout package

This package contains a keyd configuration adapted from `TEXT1NEW.ahk`, helper scripts for Wayland/KDE, and setup guides.

- [Install on this Nobara KDE computer](README-NOBARA.md)
- [Install on another Linux computer](README-LINUX.md)
- [Layout guide and key-by-key reference](GUIDE.md)

The key mapping is in `outputs/default.conf`. Companion scripts and KWin packages are kept beside it in `outputs/`; keep this directory structure when extracting the archive.
