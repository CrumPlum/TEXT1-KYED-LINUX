# Встановлення на моєму комп'ютері: Nobara KDE Wayland

Інструкція для цього комп'ютера та облікового запису `sandr`. Конфігурація прив'язана до клавіатури Compx 2.4G Wireless Receiver (`3554:fa09:6e440587`).

## Що входить

- `outputs/default.conf` — розкладка keyd.
- `keyd-insert-text.sh` — вставлення символів, email, дати й російських літер незалежно від активної розкладки.
- `keyd-google-search.sh`, `keyd-google-translate.sh`, `keyd-obsidian.sh` — дії Win+C, Win+T, Win+O.
- `keyd-raise-chrome.sh` — повертає Chrome на передній план.
- KWin-пакети й інсталятори — активація Obsidian та перемикання «Поверх інших».

## Передумови

keyd вже встановлений. Потрібні `wl-clipboard`, `kdotool`, Python 3, Flatpak Chrome `com.google.Chrome` та Obsidian `md.obsidian.Obsidian`. KWin-інсталятори використовують KDE Plasma 6 (`kpackagetool6`, `kwriteconfig6`, `qdbus6` або `qdbus`). Якщо чогось бракує:

```sh
sudo dnf install wl-clipboard kdotool
```

## Встановлення/оновлення системних файлів

Перейди в розпаковану папку `keyd-ahk-linux` і виконай:

```sh
sudo install -Dm644 outputs/default.conf /etc/keyd/default.conf
sudo install -Dm755 outputs/keyd-insert-text.sh /usr/local/bin/keyd-insert-text
sudo install -Dm755 outputs/keyd-google-search.sh /usr/local/bin/keyd-google-search
sudo install -Dm755 outputs/keyd-google-translate.sh /usr/local/bin/keyd-google-translate
sudo install -Dm755 outputs/keyd-obsidian.sh /usr/local/bin/keyd-obsidian
sudo install -Dm755 outputs/keyd-raise-chrome.sh /usr/local/bin/keyd-raise-chrome
sudo keyd check
sudo systemctl enable --now keyd
sudo systemctl restart keyd
sudo systemctl is-active keyd
```

Остання команда має надрукувати `active`. Для цієї встановленої версії keyd застосовуй конфіг перезапуском служби; `keyd reload` раніше спричиняв аварійне завершення демона.

## KWin-пакети

Виконуй від звичайного користувача, без `sudo`, перебуваючи в папці пакета:

```sh
./outputs/install-kwin-activate-launches.sh
./outputs/install-kwin-toggle-keep-above.sh
```

Перший пакет повертає Obsidian/Chrome на передній план після запуску скорочень. Другий забезпечує CapsLock+= (F14), що перемикає «Поверх інших» для активного вікна.

## Перевірка

1. У текстовому полі натисни CapsLock+1, потім CapsLock+0: мають з'явитися `!` і `)`.
2. Перевір CapsLock+L (email), CapsLock+апостроф (дата/час), стрілки CapsLock+F/G/R/V.
3. Перевір Ctrl+Alt+S та Ctrl+Alt+Shift+S для `ы` та `Ы`. Інші російські комбінації дивись у [довіднику](GUIDE.md).
4. Виділи текст і натисни Win+C для пошуку або Win+T для перекладу. Win+O запускає Obsidian.
5. Перевір CapsLock+= у звичайному вікні.

Якщо розкладка не спрацьовує, перевір `sudo systemctl status keyd --no-pager -l`, конфіг через `sudo keyd check` і події клавіатури через `sudo keyd monitor`. Для аварійного вимкнення keyd: Backspace+Escape+Enter.

## Відновлення

Поверни резервну копію `/etc/keyd/default.conf`, якщо вона створювалась, і перезапусти службу:

```sh
sudo systemctl restart keyd
```

Щоб видалити стару глобальну комбінацію Win+Ctrl+F12, якщо вона лишилася в системі, виконай від свого користувача:

```sh
kdotool --remove raise-chrome
```
